import { test, expect } from '@playwright/test';

test('hover sobre primer producto, verificar overlay y agregar al carrito', async ({ page }) => {
  await page.goto('https://automationexercise.com/');

  await page.locator('.single-products').first().hover();

  await expect(page.locator('.single-products').first().locator('.product-overlay')).toBeVisible();

  await page.getByRole('link', { name: ' View Product' }).first().click();

  await page.locator('#quantity').fill('3');

  await page.getByRole('button', { name: ' Add to cart' }).click();
  await page.getByRole('button', { name: 'Continue Shopping' }).click();

  await page.getByRole('link', { name: ' Cart' }).click();
  await expect(page.locator('button.disabled')).toHaveText('3');
});